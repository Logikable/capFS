# Cryptographic GDP Keys
This is where the GDP Keys are stored. Please do not delete this folder.

This readme acts as a placeholder for the folder, since git does not accept empty folders.
